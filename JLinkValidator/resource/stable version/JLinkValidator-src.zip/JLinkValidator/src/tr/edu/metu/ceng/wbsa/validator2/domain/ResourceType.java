package tr.edu.metu.ceng.wbsa.validator2.domain;

public enum ResourceType {
	link, image, script;
}
